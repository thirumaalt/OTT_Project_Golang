module github.com/myflix/watchhistory-service

go 1.22

require (
	github.com/gin-gonic/gin v1.10.0
	gorm.io/driver/postgres v1.5.9
	gorm.io/gorm v1.25.10
)
